import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

const linkCls = ({ isActive }) =>
  `px-3 py-2 rounded-lg transition ${
    isActive ? "bg-indigo-100 text-indigo-700" : "text-slate-700 hover:bg-slate-100"
  }`;

export default function NavBar() {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <header className="bg-white border-b">
      <nav className="container-pro flex items-center gap-3 h-16">
        <Link to="/" className="text-xl font-semibold text-indigo-700">FakeAuth</Link>
        <div className="flex items-center gap-1 ml-4">
          <NavLink to="/" className={linkCls}>Home</NavLink>
          <NavLink to="/about" className={linkCls}>About</NavLink>
          <NavLink to="/dashboard" className={linkCls}>Dashboard</NavLink>
          <NavLink to="/profile" className={linkCls}>Profile</NavLink>
        </div>
        <div className="ml-auto flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <span className="hidden sm:inline text-sm text-slate-600">
                👋 <span className="font-medium">{user.username}</span>
              </span>
              <button className="btn-outline" onClick={logout}>Logout</button>
            </>
          ) : (
            <Link to="/login" className="btn">Login</Link>
          )}
        </div>
      </nav>
    </header>
  );
}
