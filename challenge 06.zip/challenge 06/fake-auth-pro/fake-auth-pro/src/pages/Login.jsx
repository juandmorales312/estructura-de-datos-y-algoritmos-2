import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const [username, setUsername] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/dashboard";

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim()) return;
    login(username.trim());
    navigate(from, { replace: true });
  };

  return (
    <section className="max-w-md mx-auto">
      <form onSubmit={handleSubmit} className="card">
        <h2 className="h2 mb-4">Iniciar sesión</h2>
        <label className="block mb-3">
          <span className="text-sm text-slate-600">Username</span>
          <input
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="p. ej. jlopez"
          />
        </label>
        <button type="submit" className="btn w-full">Entrar</button>
        <p className="mt-3 text-xs text-slate-500">
          * Autenticación falsa solo para probar rutas protegidas.
        </p>
      </form>
    </section>
  );
}
