export default function Home() {
  return (
    <section className="grid gap-6">
      <div className="card">
        <h2 className="h2 mb-2">Bienvenido 👋</h2>
        <p className="muted">
          Proyecto de ejemplo con <strong>Login/Logout falso</strong>, Context, Provider y rutas privadas.
          Usa el menú superior para navegar. ¡Todo con una UI limpia y moderna!
        </p>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="font-semibold mb-1">Context</h3>
          <p className="muted text-sm">Manejo de sesión en toda la app.</p>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-1">Rutas privadas</h3>
          <p className="muted text-sm">Protección con <code>ProtectedRoute</code>.</p>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-1">Persistencia</h3>
          <p className="muted text-sm">Usuario guardado en <code>localStorage</code>.</p>
        </div>
      </div>
    </section>
  );
}
