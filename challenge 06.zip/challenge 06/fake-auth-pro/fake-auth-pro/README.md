# FakeAuth Pro (React + Vite + Tailwind)

App profesional con **Login/Logout falso**, **Context + Provider**, **rutas públicas/privadas** y UI moderna con **Tailwind CSS**.

## Ejecutar
```bash
npm install
npm run dev
```
Luego abre la URL que aparece (ej. `http://localhost:5173/`).

## Rutas
- Públicas: `/`, `/about`, `/login`
- Privadas: `/dashboard`, `/profile`

## Tech
- React 18, React Router 6, Vite 5
- Tailwind 3 + PostCSS + Autoprefixer
