
import { useState } from "react";

export function Counter({ defaultValue }) {
  const [count, setCount] = useState(defaultValue);

  const handleAdd = () => {
    setCount(count + 1);
  };

  const handleSubstract = () => {
    setCount(count - 1);
  };

  const handleReset = () => {
    setCount(defaultValue);
  };

  return (
    <div>
      <h1>Contador: {count}</h1>
      <button onClick={handleAdd}>➕ Sumar</button>
      <button onClick={handleSubstract}>➖ Restar</button>
      <button onClick={handleReset}>🔄 Resetear</button>
    </div>
  );
}
