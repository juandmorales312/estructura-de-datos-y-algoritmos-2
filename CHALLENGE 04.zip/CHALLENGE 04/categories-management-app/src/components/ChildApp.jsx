import React, { useState } from 'react';

export default function ChildApp({ setCategories, setCategory }) {
  const [category, setCategoryLocal] = useState("");

  const handleChange = (event) => {
    setCategoryLocal(event.target.value);
    setCategory(event.target.value);
  };

  const handleAddCategory = () => {
    if (category.trim() !== "") {
      setCategories((prevCategories) => [...prevCategories, category]);
      setCategoryLocal("");
    }
  };

  return (
    <div>
      <input 
        type="text" 
        value={category} 
        onChange={handleChange} 
        placeholder="Escribe una categoría"
        style={{ padding: '0.5rem', marginBottom: '1rem' }}
      />
      <button 
        onClick={handleAddCategory} 
        style={{ padding: '0.5rem', backgroundColor: '#4CAF50', color: 'white', border: 'none', cursor: 'pointer' }}
      >
        Agregar Categoría
      </button>
    </div>
  );
}
