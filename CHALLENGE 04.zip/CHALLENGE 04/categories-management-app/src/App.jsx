import ParentApp from './components/ParentApp.jsx'

export default function App() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <ParentApp />
    </main>
  )
}
